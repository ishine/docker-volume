#ifndef LNN_CONFIG_H_
#define LNN_CONFIG_H_

#define LNN_VERSION_MAJOR 1
#define LNN_VERSION_MINOR 0

/* #undef DEBUG */
/* #undef USE_OPENMP */

#endif  // LNN_CONFIG_H_
